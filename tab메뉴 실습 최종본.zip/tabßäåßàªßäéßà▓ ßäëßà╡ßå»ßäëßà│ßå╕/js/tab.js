$(function(){
	$("ul.panel > li:not("+$("ul.tabmenu li a.selected").attr("href")+")").hide(); // 풀어서 쓰면, $("ul.panel li:not("#tab1")").hide();
    
	$("ul.tabmenu li a").click(function(){
		$("ul.tabmenu li a").removeClass("selected");
		$(this).addClass("selected");
		$("ul.panel > li").hide();
        $("ul#line1","ul#line2").show();
		$($(this).attr("href")).show();

		return false;
	});
});	
